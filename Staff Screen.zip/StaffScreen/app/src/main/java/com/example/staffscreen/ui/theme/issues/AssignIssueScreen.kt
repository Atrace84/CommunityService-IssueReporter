package com.example.staffscreen.ui.issues

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignIssueScreen(
    issueTitle: String,
    issueDescription: String,
    issueLocation: String,
    issueCategory: String,
    repairTeams: List<String>,
    priority: String,
    onBack: () -> Unit,
    onTeamSelected: (String) -> Unit,
    onPrioritySelected: (String) -> Unit,
    onAssign: (
        team: String,
        priority: String,
        notes: String
    ) -> Unit
) {

    var selectedTeam by remember {
        mutableStateOf("")
    }

    var teamDropdownExpanded by remember {
        mutableStateOf(false)
    }

    var selectedPriority by remember {
        mutableStateOf(priority)
    }

    var priorityDropdownExpanded by remember {
        mutableStateOf(false)
    }

    var internalNotes by remember {
        mutableStateOf("")
    }


    Scaffold(

        topBar = {

            TopAppBar(

                title = {
                    Text(
                        text = "Assign Issue"
                    )
                },

                navigationIcon = {

                    IconButton(
                        onClick = onBack
                    ) {

                        Text(
                            text = "←"
                        )
                    }
                }
            )
        }

    ) { paddingValues ->

        Column(

            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(20.dp),

            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            Text(
                text = "Issue Details",
                style = MaterialTheme.typography.titleLarge
            )

            DetailItem(
                label = "Title",
                value = issueTitle
            )

            DetailItem(
                label = "Description",
                value = issueDescription
            )

            DetailItem(
                label = "Location",
                value = issueLocation
            )

            DetailItem(
                label = "Category",
                value = issueCategory
            )



            TeamSelector(
                selectedTeam = selectedTeam,

                teams = repairTeams,

                expanded = teamDropdownExpanded,

                onExpandedChange = { expanded ->

                    teamDropdownExpanded = expanded
                },

                onTeamSelected = { team ->

                    selectedTeam = team

                    teamDropdownExpanded = false

                    onTeamSelected(team)
                }
            )


            PrioritySelector(
                selectedPriority = selectedPriority,

                expanded = priorityDropdownExpanded,

                onExpandedChange = { expanded ->

                    priorityDropdownExpanded = expanded
                },

                onPrioritySelected = { newPriority ->

                    selectedPriority = newPriority

                    priorityDropdownExpanded = false

                    onPrioritySelected(newPriority)
                }
            )

            InternalNotes(
                notes = internalNotes,

                onNotesChanged = { notes ->

                    internalNotes = notes
                }
            )


            Button(

                onClick = {

                    onAssign(
                        selectedTeam,
                        selectedPriority,
                        internalNotes
                    )
                },

                modifier = Modifier
                    .fillMaxWidth(),

                enabled = selectedTeam.isNotBlank()
            ) {

                Text(
                    text = "Assign Issue"
                )
            }
        }
    }
}

@Composable
private fun DetailItem(
    label: String,
    value: String
) {

    Column(

        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {

        Text(
            text = label,

            style = MaterialTheme.typography.labelMedium,

            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text(
            text = value,

            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeamSelector(
    selectedTeam: String,
    teams: List<String>,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onTeamSelected: (String) -> Unit
) {

    Column(

        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        Text(
            text = "Repair Team",

            style = MaterialTheme.typography.titleMedium
        )

        ExposedDropdownMenuBox(

            expanded = expanded,

            onExpandedChange = onExpandedChange
        ) {

            OutlinedTextField(

                value = selectedTeam,

                onValueChange = {},

                readOnly = true,

                label = {
                    Text(
                        text = "Select repair team"
                    )
                },

                placeholder = {
                    Text(
                        text = "Choose a team"
                    )
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),

                trailingIcon = {

                    ExposedDropdownMenuDefaults.TrailingIcon(
                        expanded = expanded
                    )
                }
            )

            ExposedDropdownMenu(

                expanded = expanded,

                onDismissRequest = {
                    onExpandedChange(false)
                }
            ) {

                teams.forEach { team ->

                    DropdownMenuItem(

                        text = {
                            Text(
                                text = team
                            )
                        },

                        onClick = {
                            onTeamSelected(team)
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrioritySelector(
    selectedPriority: String,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onPrioritySelected: (String) -> Unit
) {

    Column(

        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        Text(
            text = "Priority",

            style = MaterialTheme.typography.titleMedium
        )

        ExposedDropdownMenuBox(

            expanded = expanded,

            onExpandedChange = onExpandedChange
        ) {

            OutlinedTextField(

                value = selectedPriority,

                onValueChange = {},

                readOnly = true,

                label = {
                    Text(
                        text = "Issue priority"
                    )
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),

                trailingIcon = {

                    ExposedDropdownMenuDefaults.TrailingIcon(
                        expanded = expanded
                    )
                }
            )

            ExposedDropdownMenu(

                expanded = expanded,

                onDismissRequest = {
                    onExpandedChange(false)
                }
            ) {

                listOf(
                    "Low",
                    "Medium",
                    "High"
                ).forEach { priorityOption ->

                    DropdownMenuItem(

                        text = {
                            Text(
                                text = priorityOption
                            )
                        },

                        onClick = {
                            onPrioritySelected(priorityOption)
                        }
                    )
                }
            }
        }
    }
}
@Composable
private fun InternalNotes(
    notes: String,
    onNotesChanged: (String) -> Unit
) {

    Column(

        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        Text(
            text = "Internal Notes",

            style = MaterialTheme.typography.titleMedium
        )

        OutlinedTextField(

            value = notes,

            onValueChange = onNotesChanged,

            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),

            placeholder = {
                Text(
                    text = "Add notes for the repair team..."
                )
            },

            maxLines = 6
        )
    }
}






