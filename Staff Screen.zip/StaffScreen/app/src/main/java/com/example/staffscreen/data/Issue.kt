package com.example.staffscreen.data

enum class IssuePriority {
    LOW,
    MEDIUM,
    HIGH
}

data class Issue(
    val id: String,
    val title: String,
    val description: String,
    val location: String,
    val category: String,
    val reportedDate: String,
    val priority: IssuePriority,
    val assignedTeam: String? = null,
    val internalNotes: String = ""
)

