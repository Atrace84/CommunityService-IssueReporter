package com.example.staffscreen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.example.staffscreen.ui.dashboard.StaffDashboardScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            MaterialTheme {

                Surface {

                    StaffDashboardScreen(
                        staffName = null,
                        staffRole = null,

                        openIssues = 0,
                        inProgressIssues = 0,
                        assignedIssues = 0,
                        resolvedIssues = 0,

                        recentIssues = emptyList(),

                        isLoading = false,

                        errorMessage = null,

                        onIssueClick = {},

                        onViewAllIssues = {},

                        onProfileClick = {}
                    )
                }
            }
        }
    }
}


