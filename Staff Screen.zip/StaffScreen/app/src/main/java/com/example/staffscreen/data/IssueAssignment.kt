package com.example.staffscreen.data

data class IssueAssignment(
    val issueId: String,
    val team: String,
    val priority: IssuePriority,
    val internalNotes: String
)