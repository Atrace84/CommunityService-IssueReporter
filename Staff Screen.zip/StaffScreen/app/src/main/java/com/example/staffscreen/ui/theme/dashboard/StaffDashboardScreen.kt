package com.example.staffscreen.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Card
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.Alignment
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp

private val ScreenBackground = Color(0xFFF9FAFB)
private val CardBackground = Color.White
private val CardBorderColor = Color(0xFFE5E7EB)
private val PrimaryTextColor = Color.Black
private val SecondaryTextColor = Color(0xFF6B7280)

private val StaffColorScheme = lightColorScheme(
    background = ScreenBackground,
    surface = CardBackground,
    onBackground = PrimaryTextColor,
    onSurface = PrimaryTextColor,
    onSurfaceVariant = SecondaryTextColor,
    primary = PrimaryTextColor,
    error = Color(0xFFDC2626)
)

data class IssueSummary(
    val id: String,
    val title: String,
    val category: String,
    val priority: String,
    val status: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaffDashboardScreen(
    staffName: String?,
    staffRole: String?,
    openIssues: Int,
    inProgressIssues: Int,
    assignedIssues: Int,
    resolvedIssues: Int,
    recentIssues: List<IssueSummary>,
    isLoading: Boolean,
    errorMessage: String?,
    onIssueClick: (IssueSummary) -> Unit,
    onViewAllIssues: () -> Unit,
    onProfileClick: () -> Unit
) {

    Scaffold(

        containerColor = ScreenBackground,

        topBar = {

            TopAppBar(
                title = {
                    Text("Staff Dashboard",
                        color = PrimaryTextColor
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ScreenBackground
                )
            )
        }

    ) { paddingValues ->

        when {

            isLoading -> {

                DashboardLoadingState(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                )
            }

            errorMessage != null -> {

                DashboardErrorState(
                    message = errorMessage,

                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                )
            }

            else -> {

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),

                    contentPadding = PaddingValues(20.dp),

                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {

                    item {

                        DashboardHeader(
                            staffName = staffName,
                            staffRole = staffRole
                        )
                    }

                    item {

                        Text(
                            text = "Dashboard",
                            style = MaterialTheme.typography.headlineMedium
                        )
                    }

                    item {

                        DashboardStats(
                            openIssues = openIssues,
                            inProgressIssues = inProgressIssues,
                            assignedIssues = assignedIssues,
                            resolvedIssues = resolvedIssues
                        )
                    }

                    item {

                        Text(
                            text = "Recent Issues",
                            color = PrimaryTextColor
                        )
                    }

                    if (recentIssues.isEmpty()) {

                        item {

                            Text(
                                text = "No recent issues available.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SecondaryTextColor
                            )
                        }

                    } else {

                        items(
                            items = recentIssues,
                            key = { issue ->
                                issue.id
                            }
                        ) { issue ->

                            IssueSummaryCard(
                                issue = issue,
                                onClick = {
                                    onIssueClick(issue)
                                }
                            )
                        }
                    }

                    item {

                        DashboardActions(
                            onViewAllIssues = onViewAllIssues,
                            onProfileClick = onProfileClick
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardStats(
    openIssues: Int,
    inProgressIssues: Int,
    assignedIssues: Int,
    resolvedIssues: Int
) {

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            StatCard(
                title = "Open Issues",
                value = openIssues.toString(),
                modifier = Modifier.weight(1f)
            )

            StatCard(
                title = "In Progress",
                value = inProgressIssues.toString(),
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            StatCard(
                title = "Assigned",
                value = assignedIssues.toString(),
                modifier = Modifier.weight(1f)
            )

            StatCard(
                title = "Resolved",
                value = resolvedIssues.toString(),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardBackground
        ),
        border = BorderStroke(1.dp, CardBorderColor)
    ) {

        Column(
            modifier = Modifier.padding(16.dp),

            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = title,

                style = MaterialTheme.typography.labelLarge,

                color = SecondaryTextColor
            )

            Text(
                text = value,

                style = MaterialTheme.typography.headlineMedium,

                color = PrimaryTextColor,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun IssueSummaryCard(
    issue: IssueSummary,
    onClick: () -> Unit
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = CardBackground
        ),
        border = BorderStroke(1.dp, CardBorderColor)
    ) {

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = issue.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = PrimaryTextColor
                )

                StatusBadge(status = issue.status)
            }

            Text(
                text = "Priority: ${issue.priority}",
                style = MaterialTheme.typography.bodyMedium,
                color = SecondaryTextColor
            )

            Text(
                text = "Status: ${issue.status}",
                style = MaterialTheme.typography.bodyMedium,
                color = PrimaryTextColor
            )
        }
    }
}

@Composable
private fun StatusBadge(status: String) {
    val (backgroundColor, textColor) = when (status) {
        "Reported" -> Color(0xFFFEE2E2) to Color(0xFF991B1B)    // Soft Red / Pink
        "In Progress" -> Color(0xFFDBEAFE) to Color(0xFF1E40AF) // Soft Blue
        "Assigned" -> Color(0xFFFEF3C7) to Color(0xFF92400E)    // Soft Yellow
        else -> Color(0xFFF3F4F6) to Color(0xFF374151)          // Soft Neutral Gray
    }

    Surface(
        color = backgroundColor,
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun DashboardLoadingState(
    modifier: Modifier = Modifier
) {

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {

        CircularProgressIndicator(color = PrimaryTextColor)
    }
}

@Composable
private fun DashboardErrorState(
    message: String,
    modifier: Modifier = Modifier
) {

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {

        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.error
        )
    }
}

@Composable
private fun DashboardActions(
    onViewAllIssues: () -> Unit,
    onProfileClick: () -> Unit
) {

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Button(
            onClick = onViewAllIssues,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = PrimaryTextColor,
                contentColor = CardBackground
            )
        ) {
            Text("View All Issues")
        }

        OutlinedButton(
            onClick = onProfileClick,
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, CardBorderColor),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = PrimaryTextColor)
        ) {
            Text("Profile")
        }
    }
}

@Composable
private fun DashboardHeader(
    staffName: String?,
    staffRole: String?
) {

    Column(
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {

        Text(
            text = if (staffName.isNullOrBlank()) {
                "Welcome"
            } else {
                "Welcome, $staffName"
            },
            color = PrimaryTextColor
        )

        if (!staffRole.isNullOrBlank()) {

            Text(
                text = staffRole,
                style = MaterialTheme.typography.bodyMedium,
                color = SecondaryTextColor
            )
        }
    }
}









